package com.loplat.loplatsample;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.location.LocationManager;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.loplat.placeengine.Plengi;
import com.loplat.placeengine.PlengiResponse;
import com.loplat.placeengine.utils.LoplatLogger;

import java.util.List;


public class MainActivity extends AppCompatActivity {

    BroadcastReceiver mLoplatBroadcastReceiver;
    ProgressDialog mProgressDialog=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView tv_result = (TextView)findViewById(R.id.tv_result);

        // receive response from loplat listener
        mLoplatBroadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if(action.equals("com.loplat.mode.response")) {
                    try {
                        if (mProgressDialog!=null&&mProgressDialog.isShowing()) {
                            mProgressDialog.dismiss();
                        }
                    }
                    catch ( Exception e ) {
                        e.printStackTrace();
                    }

                    String type = intent.getStringExtra("type");
                    if(type == null) {
                        return;
                    }

                    System.out.println("mLoplatBroadcastReceiver: " + type);
                    Log.d("LoplatSample","mLoplatBroadcastReceiver: " + type);

                    if(type.equals("error")) {
                        String response = intent.getStringExtra("response");
                        Log.d("LoplatSample",response);
                        tv_result.setText(response);
                    }
                    else {
                        if (type.equals("placeinfo")) {
                            String response = intent.getStringExtra("response");
                            Log.d("LoplatSample",response);
                            tv_result.setText(response);
                        }
                        else if(type.equals("placeevent")) {
                            String response = intent.getStringExtra("response");
                            Log.d("LoplatSample",response);
                            tv_result.setText(response);
                        }
                    }
                }
            }
        };
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction("com.loplat.mode.response");
        registerReceiver(mLoplatBroadcastReceiver, intentFilter);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        unregisterReceiver(mLoplatBroadcastReceiver);
    }

    @Override
    protected void onResume() {
        super.onResume();

        final TextView tv_status = (TextView)findViewById(R.id.tv_status);
        final TextView tv_result = (TextView)findViewById(R.id.tv_result);

        int currentPlaceStatus = Plengi.getInstance(this).getCurrentPlaceStatus();

        switch (currentPlaceStatus) {
            case PlengiResponse.PlaceStatus.MOVE:
                tv_status.setText("Welcome to loplat");
                break;

            case PlengiResponse.PlaceStatus.STAY:
                tv_status.setText("Staying...");

                PlengiResponse.Place currentPlace = Plengi.getInstance(this).getCurrentPlaceInfo();
                List<PlengiResponse.Visit> visits = Plengi.getInstance(null).getVisitList();
                if(visits.size() >= 1) {
                    PlengiResponse.Visit visit = visits.get(visits.size() - 1);
                    long duration = (System.currentTimeMillis() - visit.enter) / 60000;
                    if (currentPlace.name == null) {
                        tv_result.setText("Unknown Place (" + duration / 60 + "시간 " + duration % 60 + "분)");
                    } else {
                        String name = currentPlace.name;
                        String tags = currentPlace.tags;
                        String category = currentPlace.category;
                        int floor = currentPlace.floor;
                        String info = name + ", " + tags + ", " + category + ", " + floor + "F\n";
                        tv_result.setText("" + info + "(" + duration / 60 + "시간 " + duration % 60 + "분째)");
                    }
                }
                break;
        }

    }


    public void onInitPlaceEngine(View view) {
        // do init process only once before calling other functions
        //mPlengi.init("yanolja","yanolja1611", Build.SERIAL);
        String clientId = "jinair";
        String clientSecret = "jinair1611";
        /* Please be careful not to input any personal information such as email, phone number. */
        String uniqueUserId = "loplat_sample_12345";
        int result = Plengi.getInstance(this).init(clientId, clientSecret, uniqueUserId);
        if(result == PlengiResponse.Result.SUCCESS) {
            // ok
            LoplatLogger.writeLogFile("LoplatSample -> Init OK");
            Log.d("LoplatSample","Init OK");
        }
        else if(result == PlengiResponse.Result.FAIL_INTERNET_UNAVAILABLE) {
            // internet is not connectedA
            // need to retry "init"
            Log.d("LoplatSample","Internet Unavailable");
            LoplatLogger.writeLogFile("LoplatSample -> Internet Unavailable");
        }
        else if(result == PlengiResponse.Result.FAIL_WIFI_SCAN_UNAVAILABLE) {
            // wifi scan is not available
            // but, in the "init" process, this error does not matter
            Log.d("LoplatSample","WiFi Scan Unavailable");
            LoplatLogger.writeLogFile("LoplatSample -> WiFi Scan Unavailable");
        }

        // set scan period (optional)
        //set tracking mode
        Plengi.getInstance(this).setScanPeriodTracking(20*1000);
        Plengi.getInstance(this).setMonitoringType(PlengiResponse.MonitoringType.TRACKING);
//        int moveScanPeriod = 3 * 60000; // 3 mins (milliseconds)
//        int stayScanPeriod = 6 * 60000; // 6 mins (milliseconds)
//        Plengi.getInstance(this).setScanPeriod(moveScanPeriod, stayScanPeriod);

    }

    public void onRequestLocationInfo(View view) {
        // request location to loplat engine
        int result = Plengi.getInstance(this).refreshPlace();

        if(result == PlengiResponse.Result.SUCCESS) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    mProgressDialog = new ProgressDialog(MainActivity.this);
                    mProgressDialog.setMessage("I'm scanning wifi. Please wait...");
                    mProgressDialog.setCancelable(true);
                    mProgressDialog.show();
                }
            });
        }
        else if(result == PlengiResponse.Result.FAIL_INTERNET_UNAVAILABLE) {
            // internet is not connected
        }
        else if(result == PlengiResponse.Result.FAIL_WIFI_SCAN_UNAVAILABLE) {
            // wifi scan is not available
        }
    }

    public void onStartPlaceMonitoring(View view) {
        // request location to loplat engine

        int result = Plengi.getInstance(this).start();

        if(result == PlengiResponse.Result.SUCCESS) {
            Log.d("LoplatSample","LoplatPlengi start");
            LoplatLogger.writeLogFile("LoplatSample -> start engine");
            // ok
        }
        else if(result == PlengiResponse.Result.FAIL_INTERNET_UNAVAILABLE) {
            // internet is not connected
            LoplatLogger.writeLogFile("LoplatSample -> FAIL_INTERNET_UNAVAILABLE");
        }
        else if(result == PlengiResponse.Result.FAIL_WIFI_SCAN_UNAVAILABLE) {
            // wifi scan is not available
            LoplatLogger.writeLogFile("LoplatSample -> FAIL_WIFI_SCAN_UNAVAILABLE");
        }
    }

    public void onStopPlaceMonitoring(View view) {
        // request location to loplat engine
        int result = Plengi.getInstance(this).stop();

        if(result == PlengiResponse.Result.SUCCESS) {
            // ok
            LoplatLogger.writeLogFile("LoplatSample -> Stop engine");
        }
        else if(result == PlengiResponse.Result.FAIL_INTERNET_UNAVAILABLE) {
            // internet is not connected
        }
        else if(result == PlengiResponse.Result.FAIL_WIFI_SCAN_UNAVAILABLE) {
            // wifi scan is not available
        }
    }


    // Sample code for checking WiFi Scanning Condition in Mashmallow
    private void checkWiFiScanConditionInMashmallow(Context context) {

        if(Build.VERSION.SDK_INT < 23) {
            return;
        }

        LocationManager locationManager = (LocationManager)context.getSystemService(context.LOCATION_SERVICE);
        boolean isNetworkEnabled = locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
        boolean isGPSEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER);
        if(!isNetworkEnabled && !isGPSEnabled) {
            // please turn on location settings
        }


        PackageManager pm = context.getPackageManager();
        int permission = pm.checkPermission(Manifest.permission.ACCESS_FINE_LOCATION, context.getPackageName());
        int subpermission = pm.checkPermission(Manifest.permission.ACCESS_COARSE_LOCATION, context.getPackageName());
        if(permission != PackageManager.PERMISSION_GRANTED && subpermission != PackageManager.PERMISSION_GRANTED) {
            // please enable permission on location access
        }
    }

}
